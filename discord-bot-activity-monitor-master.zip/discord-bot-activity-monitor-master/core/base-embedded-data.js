const Camo = require("camo");

// @ts-ignore
module.exports = class BaseEmbeddedData extends Camo.EmbeddedDocument {
    constructor() {
        super();
    }
};